package eu.kanade.tachiyomi.ui.setting

import android.app.Activity
import android.content.Intent
import androidx.browser.customtabs.CustomTabsIntent
import androidx.preference.PreferenceScreen
import eu.kanade.tachiyomi.R
import eu.kanade.tachiyomi.data.track.EnhancedTrackService
import eu.kanade.tachiyomi.data.track.TrackManager
import eu.kanade.tachiyomi.data.track.TrackService
import eu.kanade.tachiyomi.data.track.anilist.AnilistApi
import eu.kanade.tachiyomi.data.track.bangumi.BangumiApi
import eu.kanade.tachiyomi.data.track.hikka.HikkaApi
import eu.kanade.tachiyomi.data.track.mangabaka.MangaBakaApi
import eu.kanade.tachiyomi.data.track.shikimori.ShikimoriApi
import eu.kanade.tachiyomi.ui.setting.track.MyAnimeListLoginActivity
import eu.kanade.tachiyomi.util.preference.defaultValue
import eu.kanade.tachiyomi.util.preference.infoPreference
import eu.kanade.tachiyomi.util.preference.initThenAdd
import eu.kanade.tachiyomi.util.preference.onClick
import eu.kanade.tachiyomi.util.preference.preferenceCategory
import eu.kanade.tachiyomi.util.preference.switchPreference
import eu.kanade.tachiyomi.util.preference.titleRes
import eu.kanade.tachiyomi.util.system.getResourceColor
import eu.kanade.tachiyomi.widget.preference.LoginPreference
import eu.kanade.tachiyomi.widget.preference.TrackLoginDialog
import eu.kanade.tachiyomi.widget.preference.TrackLogoutDialog
import uy.kohesive.injekt.injectLazy
import eu.kanade.tachiyomi.data.preference.PreferenceKeys as Keys

class SettingsTrackingController :
    SettingsController(),
    TrackLoginDialog.Listener,
    TrackLogoutDialog.Listener {
    private val trackManager: TrackManager by injectLazy()

    override fun setupPreferenceScreen(screen: PreferenceScreen) =
        with(screen) {
            titleRes = R.string.pref_category_tracking

            switchPreference {
                key = Keys.autoUpdateTrack
                titleRes = R.string.pref_auto_update_manga_sync
                defaultValue = true
            }
            switchPreference {
                key = Keys.trackMarkedAsRead
                titleRes = R.string.pref_track_marked_as_read
                defaultValue = true
            }
            preferenceCategory {
                titleRes = R.string.services

                trackPreference(trackManager.myAnimeList) {
                    startActivity(MyAnimeListLoginActivity.newIntent(activity!!))
                }
                trackPreference(trackManager.aniList) {
                    val tabsIntent =
                        CustomTabsIntent.Builder()
                            .setToolbarColor(context.getResourceColor(androidx.appcompat.R.attr.colorPrimary))
                            .build()
                    tabsIntent.intent.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY)
                    tabsIntent.launchUrl(activity!!, AnilistApi.authUrl())
                }
                trackPreference(trackManager.kitsu) {
                    val dialog = TrackLoginDialog(trackManager.kitsu, R.string.email)
                    dialog.targetController = this@SettingsTrackingController
                    dialog.showDialog(router)
                }
                trackPreference(trackManager.shikimori) {
                    val tabsIntent =
                        CustomTabsIntent.Builder()
                            .setToolbarColor(context.getResourceColor(androidx.appcompat.R.attr.colorPrimary))
                            .build()
                    tabsIntent.intent.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY)
                    tabsIntent.launchUrl(activity!!, ShikimoriApi.authUrl())
                }
                trackPreference(trackManager.mangaBaka) {
                    val tabsIntent =
                        CustomTabsIntent.Builder()
                            .setToolbarColor(context.getResourceColor(androidx.appcompat.R.attr.colorPrimary))
                            .build()
                    tabsIntent.intent.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY)
                    tabsIntent.launchUrl(activity!!, MangaBakaApi.authUrl())
                }
                trackPreference(trackManager.hikka) {
                    val tabsIntent =
                        CustomTabsIntent.Builder()
                            .setToolbarColor(context.getResourceColor(androidx.appcompat.R.attr.colorPrimary))
                            .build()
                    tabsIntent.intent.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY)
                    tabsIntent.launchUrl(activity!!, HikkaApi.authUrl())
                }
                trackPreference(trackManager.mangaUpdates) {
                    val dialog = TrackLoginDialog(trackManager.mangaUpdates, R.string.username)
                    dialog.targetController = this@SettingsTrackingController
                    dialog.showDialog(router)
                }
                trackPreference(trackManager.bangumi) {
                    val tabsIntent =
                        CustomTabsIntent.Builder()
                            .setToolbarColor(context.getResourceColor(androidx.appcompat.R.attr.colorPrimary))
                            .build()
                    tabsIntent.intent.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY)
                    tabsIntent.launchUrl(activity!!, BangumiApi.authUrl())
                }
            }
            preferenceCategory {
                titleRes = R.string.enhanced_services

                enhancedTrackPreference(trackManager.komga)
                enhancedTrackPreference(trackManager.kavita)
                enhancedTrackPreference(trackManager.suwayomi)

                infoPreference(R.string.enhanced_tracking_info)
            }
            preferenceCategory {
                infoPreference(R.string.tracking_info)
            }
        }

    /**
     * Enhanced trackers have no credentials of their own - they reuse the bound source's. So the
     * preference just toggles them on and off.
     */
    private fun PreferenceScreen.enhancedTrackPreference(service: TrackService): LoginPreference {
        return initThenAdd(
            LoginPreference(context).apply {
                key = Keys.trackUsername(service.id)
                title = service.name
            },
            {
                onClick {
                    if (service.isLogged) {
                        service.logout()
                    } else {
                        (service as EnhancedTrackService).loginNoop()
                    }
                    updatePreference(service.id)
                }
            }
        )
    }

    private inline fun PreferenceScreen.trackPreference(
        service: TrackService,
        crossinline login: () -> Unit
    ): LoginPreference {
        return initThenAdd(
            LoginPreference(context).apply {
                key = Keys.trackUsername(service.id)
                title = service.name
            },
            {
                onClick {
                    if (service.isLogged) {
                        val dialog = TrackLogoutDialog(service)
                        dialog.targetController = this@SettingsTrackingController
                        dialog.showDialog(router)
                    } else {
                        login()
                    }
                }
            }
        )
    }

    override fun onActivityResumed(activity: Activity) {
        super.onActivityResumed(activity)

        // Manually refresh OAuth trackers' holders
        updatePreference(trackManager.myAnimeList.id)
        updatePreference(trackManager.aniList.id)
        updatePreference(trackManager.shikimori.id)
        updatePreference(trackManager.bangumi.id)
    }

    private fun updatePreference(id: Int) {
        val pref = findPreference(Keys.trackUsername(id)) as? LoginPreference
        pref?.notifyChanged()
    }

    override fun trackLoginDialogClosed(service: TrackService) {
        updatePreference(service.id)
    }

    override fun trackLogoutDialogClosed(service: TrackService) {
        updatePreference(service.id)
    }
}
